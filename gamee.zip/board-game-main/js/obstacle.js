// Create obstacle class
class Obstacle {
    constructor(name, image) {
        this.name = name;
        this.image = image;
    }
}

// Create the obstacle object
const gameObstacle = new Obstacle("rock", "images/rock.png");
