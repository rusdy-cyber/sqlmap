// ----- Player Class
class Player {
  constructor(name, id) {
    this.name = name;
    this.id = id;
    this.weapon = {weapon: []}; 
  } 
}

