runcmd.exe is an auxiliary program that can be used for running command prompt
commands skipping standard "cmd /c" way. It is licensed under the terms of the
GNU Lesser General Public License.
